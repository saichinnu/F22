import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{SearchFormComponent}from './search-form/search-form.component';
import{ProductListComponent}from './product-list/product-list.component';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'search', component: SearchFormComponent},
  {path:'List', component: ProductListComponent}
];
@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes),
    CommonModule
  ]
})
export class AppRoutingModule {

 }
